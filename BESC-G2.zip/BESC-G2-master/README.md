# BESC-G2
BESC second generation

Based on BESC. 

BESC-G2 is licensed under the Creative Commons Attribution-ShareAlike 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/4.0/.
